# For first initial condition, u(L,t)= 0
import numpy as np
import matplotlib.pyplot as plt

L = 1.0
N = 1000

a = 1
w = 100.0

xs,h  = np.linspace(0,L,N,retstep=True)
us = np.where(xs<L/2,2*xs,2-2*xs)
bdry = np.zeros(N-2)
bdry[0] = us[0]

dt = .0004

mu = dt/(2*h*h)

t = 0
tf = 10.0

line, = plt.plot(xs,us)
plt.ylim(-.5,1.1)


C = np.eye(N-2)*(1-2*mu) +mu* np.eye(N-2,k=1) +mu*np.eye(N-2,k=-1)
D = np.linalg.inv(np.eye(N-2)*(1 +2*mu) -mu* np.eye(N-2,k=1) -mu*np.eye(N-2,k=-1)) 


while t<tf:
    us[-1] = 0
    bdry[-1] = 2*mu*us[-1]

    us[1:-1] = np.dot(C,us[1:-1])
    us[1:-1]= np.dot(D, us[1:-1]+bdry)
    t += dt
    line.set_ydata(us)
    plt.title(f"$\\delta t = {dt}$ and $ \\delta x = {round(h,5)}$ ")
    plt.xlabel("x")
    plt.ylabel("$\\psi (x,t)$")
    plt.pause(.0001)

plt.show()
#* (np.eye(N-2)*(2-2*mu) +mu* np.eye(N-2,k=1) +mu*np.eye(N-2,k=-1))

