import numpy as np
import matplotlib.pyplot as plt

from matplotlib import animation, rc
from IPython.display import HTML

def gaussin(x,sigma,x0):
    return (1/(sigma*np.sqrt(2*np.pi))) * np.exp(-((x-x0)**2)/(2*sigma**2))
# Grid points
N = 401
# Create the grid
xs, h = np.linspace(-10,10.0,N,retstep=True)

# Timestep
delt = 0.01
sigma = 0.2
x0= 3

# Given potential
U = np.where((xs > 5) & (xs < 7), 40, 0)
# Initial condition
phi0 = gaussin(xs,sigma,x0)


# Boundary condition
p0 = 0.0
pN = 0.0
# A parameter used in expressions
k = 2.0j/delt
# Construct A
A = (k*np.eye(N) - np.diag(U))*h**2 - 2*np.eye(N) + np.eye(N,k=1) + np.eye(N,k=-1)
# Find inverse of A
Ainv = np.linalg.inv(A)
# Calculate the propagator
Uprop = Ainv*(4*1j*h**2)/delt - np.eye(N)
# print(A)
# Begin from the initial condition
phi = phi0
# set initial and final times
t = 0.0
tfinal = 10.0
# k keeps track of iterations
k = 0
plt.plot(xs, U/np.max(U))

line = plt.plot(xs,np.real(phi))[0]
while t<tfinal:
    # Evolve
    phi = np.dot(Uprop,phi)
    # Set boundary
    phi[0] = p0

    phi[-1] = pN
    # Increment t
    t += delt
    # plot after every 40 iteration
    line.set_ydata(np.real(phi))
    plt.xlabel("x")
    plt.ylabel("$\\psi (x,t)$")
    plt.pause(.0001)
    plt.ylim(-2 ,4)
    # increment k
    k += 1
