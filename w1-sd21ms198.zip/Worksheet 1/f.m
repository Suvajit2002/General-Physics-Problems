function v = f(x,n)

v = 1;
s=1;
if n==1
    v = 1;
else
for j = 1:n
    s = s* (x/j);
    v = v + s;
end 
end 
