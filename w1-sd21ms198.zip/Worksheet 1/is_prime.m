function s= is_prime(n)

if n ==3 || n==2
     s = true; 
elseif n ==1
    s = false;

else
for i = 2:floor(sqrt(n))+1
    
    if mod(n,i)==0
        s = false;
        break;
    end
   s = true;
end

end 
end
