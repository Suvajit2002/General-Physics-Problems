format long
p = zeros(10,5);
x = linspace(0.1,1.0,10);
n = linspace(4,20,5);


for i = 1:size(x,2)
    for j = 1:size(n,2)
        p(i,j)= f(x(i),n(j));

    end 
end 
p = num2str(p,'%12.6f');

disp(p);
