
t=10;
z = zeros(t,2);
n= linspace(1,t,t);
for i = 1:size(n,2)
    for j = 1:2
        if j ==1
            z(i,j)= pi_leb(i);
        else 
            z(i,j)= pi_con(i);
        end 
    end 
end
fprintf('Leibniz \t Continued\n')

disp(z)
figure;
plot(n,z(:,1), 'b-', 'LineWidth', 2);

hold on;
plot(n,z(:,2),'r','LineWidth',2.4)
legend('Leibniz','Continued')
%%
function s = pi_leb(n)

s = 0;
for i = 1:n
    s = s -(cos(i*pi))/((2*i-1));
end 
s = 4*s;
end 
%%
function v = pi_con(n)
t=0;
for i = n:-1:1
    t = ((2*i-1)^2)/(2+t);
end 
v = 4/(1+t);

end 

