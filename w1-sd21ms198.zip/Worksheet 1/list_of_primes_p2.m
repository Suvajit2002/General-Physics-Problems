function t = list_of_primes_p2(x,y)

s= linspace(x,y,y-x+1);
t = [];
for i = 1:size(s,2)
    if is_prime(i)==true
        t = [t,i];
    end 
end 



% Write a function that generates all prime numbers between any two given integers

