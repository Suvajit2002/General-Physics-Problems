
% Function is defined at the end of the script.

tol = 10^(-6);
x = linspace(-1.2,1,100); % having 100 points on x axis between -1.2 and 1
y = V(x);
max_iter=100;

% If you want to see the plot, uncomment the following portion of the
% script. 
% figure;
% plot(x,y,'b');
% yline(0); 


% Four turning points are in this case and by plotting the function we now
% have the eye estimations of the intervals where the roots lie. 

% 1st interval = [-1.2,-1]
% 2nd Interval = [-0.4,-0.3]
% 3rd Interval = [0.2,0.5]
% 4th Interval = [0.66,0.8]


disp('Bisection Method')
fprintf("1st Turning point: %f \n",bisection(-1.2,-1,max_iter,tol,@V))
fprintf("2nd Turning point: %f\n",bisection(-0.4,-0.3,max_iter,tol,@V))
fprintf("3rd Turning point: %f\n",bisection(0.2,0.5,max_iter,tol,@V))
fprintf("4th Turning point: %f\n",bisection(0.66,0.8,max_iter,tol,@V))


disp('Regula-Falsi Method')
fprintf("1st Turning point: %f \n",regulafalsi(-1.2,-1,max_iter,tol,@V))
fprintf("2nd Turning point: %f\n",regulafalsi(-0.4,-0.3,max_iter,tol,@V))
fprintf("3rd Turning point: %f\n",regulafalsi(0.2,0.5,max_iter,tol,@V))
fprintf("4th Turning point: %f\n",regulafalsi(0.66,0.8,max_iter,tol,@V))

disp('Secant Method')
fprintf("1st Turning point: %f \n",secant(-1.2,-1,max_iter,tol,@V))
fprintf("2nd Turning point: %f\n",secant(-0.4,-0.3,max_iter,tol,@V))
fprintf("3rd Turning point: %f\n",secant(0.2,0.5,max_iter,tol,@V))
fprintf("4th Turning point: %f\n",secant(0.66,0.8,max_iter,tol,@V))

disp('Newton-Rapson Method')

fprintf("1st Turning point: %f \n",newton(-1.2,max_iter,tol,@V,@fv))
fprintf("2nd Turning point: %f\n",newton(-0.4,max_iter,tol,@V,@fv))
fprintf("3rd Turning point: %f\n",newton(0.2,max_iter,tol,@V,@fv))
fprintf("4th Turning point: %f\n",newton(0.66,max_iter,tol,@V,@fv))




%%


function R = newton(x, max_iter, tol, f, fv)

    % x is the initial guess
    % max_iter is the maximum number of iterations
    % tol is the tolerance for convergence
    % f is the function whose root is being sought
    % fv is the derivative of the function

    R = x; % Initialize the root
    
    iter = 0;
    
    while abs(f(R)) > tol
        if fv(R) == 0
            disp('Function has an extremum.');
            break;
        else
            R = R - (f(R) / fv(R));
        end

        iter = iter + 1;

        if iter == max_iter
            disp('The program has not reached convergence within the specified number of iterations. Please use another algorithm.');
            R = NaN; % Return a special value or handle the error 
            return;
        end 
    end
end

%%

function R = secant(L,R,max_iter,tol,f)

% L and R the bracketing value
% tol is my bisection error
% ar is actual root of the problem 
% I don't want to pass max_iter as parameter but it'll create problem in
% upcoming codes. So I taken it as parameter. 

iter= 0;
while abs(f(R))>tol
      % Update L and R using the secant method formula
        temp = R;
        R = R - (f(R) * (R - L)) / (f(R) - f(L));
        L = temp;


    iter = iter +1;
    if iter==max_iter
        disp('Our program has not able to reach the convergence. Sorry use any other algorithm. ') % Number of iterations exceed the preset value of max iterations.
        R = NaN; % Return a special value or handle the error 
        return;
    end 

end
end

%%
function val = bisection(L,R,max_iter,tol,f)

% L and R the bracketing value
% tol is my bisection error
% ar is actual root of the problem 
% I don't want to pass max_iter as parameter but it'll create problem in
% upcoming codes. So I taken it as parameter. 

    c = (L+R)/2;
for i = 1:max_iter
    if f(c)*f(L)<0 % checking whether our computed guess in this step contains the root or not. 
        R=c;
    else
        L=c;
    end
    c=(L+R)/2; % Decreasing the interval size with every step
    if abs(f(c))<tol % checking whether our fucntion value has gone under our tolerance value or not. 
        val =c;
        break;
    end
    if i == max_iter
        disp('Our program has not able to reach the convergence. Sorry use any other algorithm. ') % Number of iterations exceed the preset value of max iterations.
        val = NaN; % Return a special value or handle the error 
        return;
    end 
    
end
end 
%%
function val = regulafalsi(L,R,max_iter,tol,f)

% L and R the bracketing value
% tol is my bisection error
% ar is actual root of the problem 
% I don't want to pass max_iter as parameter but it'll create problem in
% upcoming codes. So I taken it as parameter. 

    c = (L*f(R)-R*f(L))/(f(R)-f(L));
for i = 1:max_iter
    if f(c)*f(L)<0 % checking whether our computed guess in this step contains the root or not. 
        R=c;
    else
        L=c;
    end
    c=(L*f(R)-R*f(L))/(f(R)-f(L)); % Decreasing the interval size with every step
    if abs(f(c))<tol % checking whether our fucntion value has gone under our tolerance value or not. 
        val =c;
        break;
    end
    if i == max_iter
        disp('Our program has not able to reach the convergence. Sorry use any other algorithm. ') % Number of iterations exceed the preset value of max iterations.
        val = NaN; % Return a special value or handle the error 
        return;
    end 
    
end
end



%%
function val = fv(x)
val = -(4*(x^3) + 2*((2*x)/3)^2 -2*x);
end 
%%

function val = V(x)
 val = -0.125- (x.^4 + ((2*x)/3).^3 -x.^2);
end 