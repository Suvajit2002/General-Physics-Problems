L = -4;
R = -2.5;
tol = 10^(-6);
max_iter = 100;
%f1 = @(x) (x+3)*((x-1)^2);
ar1 = -3;
bisection_result = bisection(L,R,max_iter,tol,@f1,ar1);



%%
function val = bisection(L,R,max_iter,tol,f,ar)

% L and R the bracketing value
% tol is my bisection error
% ar is actual root of the problem 
% I don't want to pass max_iter as parameter but it'll create problem in
% upcoming codes. So I taken it as parameter. 
if (ar-L)*(ar-R)>0
    disp("It's a bad interval.") % Checking whether bracket contain the root or not. 
    val = NaN; % Return a special value or handle the error 
    return;
else 
    c = (L+R)/2;
    fprintf("Step \t Computed Guess(c) \t Actual root - c \n ") 
for i = 1:max_iter
    if f(c)*f(L)<0 % checking whether our computed guess in this step contains the root or not. 
        R=c;
    else
        L=c;
    end
    c=(L+R)/2; % Decreasing the interval size with every step
    fprintf('%d \t %f \t\t %f  \n', round(i,4),round(c,4), ar- round(c,4));
    if abs(f(c))<tol % checking whether our fucntion value has gone under our tolerance value or not. 
        val =c;
        fprintf('Total number of steps is %d and root is %f',i,val);
        break;
    end
    if i == max_iter
        disp('Our program has not able to reach the convergence. Sorry use any other algorithm. ') % Number of iterations exceed the preset value of max iterations.
        val = NaN; % Return a special value or handle the error 
        return;
    end 
    
end
end 
end
%%
function val = f1(x)

    val = (x+3)*((x-1)^2);
end