L = 1.2; 
R = 1.4;
% Our checking interval is [1.2,1.4]
tol = 10^(-6);
max_iter = 100;

bisection_result = bisection(L,R,max_iter,tol,@f2);



%%
function val = bisection(L,R,max_iter,tol,f)

% L and R the bracketing value
% tol is my bisection error
% ar is actual root of the problem 
% I don't want to pass max_iter as parameter but it'll create problem in
% upcoming codes. So I taken it as parameter. 

    c = (L+R)/2;
    fprintf("Step \t Computed Guess(c) \n ") 
for i = 1:max_iter
    if f(c)*f(L)<0 % checking whether our computed guess in this step contains the root or not. 
        R=c;
    else
        L=c;
    end
    c=(L+R)/2; % Decreasing the interval size with every step
    fprintf('%d \t %f \n', round(i,4),round(c,4));
    if abs(f(c))<tol % checking whether our fucntion value has gone under our tolerance value or not. 
        val =c;
        fprintf('Total number of steps is %d and root is %f',i,val);
        break;
    end
    if i == max_iter
        disp('Our program has not able to reach the convergence. Sorry use any other algorithm. ') % Number of iterations exceed the preset value of max iterations.
        val = NaN; % Return a special value or handle the error 
        return;
    end 
    
end
end 

%%
function val = f2(x) 

    val = x-(1/3)*tan(x);
end